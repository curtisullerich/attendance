package AttendanceProject;

public class AttendanceRecord 
{
	

}
